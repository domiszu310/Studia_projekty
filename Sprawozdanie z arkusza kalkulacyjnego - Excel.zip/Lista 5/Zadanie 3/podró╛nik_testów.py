from podróżnik_w_czasie import new_wiadomość, new_słownik, najkrótsze_słowo, słownik, wiadomość
from itertools import permutations

def znajdź_słowa(słownik, wiadomość):
    rozwiązanie = set()
    nowa_wiadomość = new_wiadomość(słownik, wiadomość)
    for słowo in słownik:
        if słowo in nowa_wiadomość:
            rozwiązanie.add(słowo)
    return rozwiązanie

#słownik = ['smok', 'marchewka', 'autobus', 'pi']
#wiadomość = "amaurtcheobwuksa"

#print(znajdź_słowa(słownik, wiadomość))

def znajdz_słowa(słownik, wiadomość):
    przefiltrowana_wiadomość = new_wiadomość(słownik, wiadomość)
    nowy_słownik_z_filtrami = new_słownik(słownik, przefiltrowana_wiadomość)
    return znajdz_najwiecej_slow(nowy_słownik_z_filtrami, przefiltrowana_wiadomość)

def znajdz_najwiecej_slow(słownik, wiadomość):
    if not wiadomość:
        return set()
    najlepszy = set()
    for i in range(1, len(wiadomość) + 1):
        for j in range(len(wiadomość) - i + 1):
            podciag = wiadomość[j:j+i]
            if podciag in słownik:
                reszta = wiadomość[:j] + wiadomość[j+i:]
                wynik_dla_reszty = znajdz_najwiecej_slow(słownik, reszta)
                wynik_dla_reszty.add(podciag)
                if len(wynik_dla_reszty) > len(najlepszy):
                    najlepszy = wynik_dla_reszty
    return najlepszy

#print(znajdz_słowa(słownik, wiadomość)) zwraca jedno słowo

def znajdź_słowa(słownik, wiadomość): # funkcja znajduje słowa ze słownika w wiadomości
    rozwiązanie = set()
    nowa_wiadomość = new_wiadomość(słownik, wiadomość)
    nowy_słownik = new_słownik(słownik, nowa_wiadomość)
    l = len(nowa_wiadomość)
    minimum = najkrótsze_słowo(nowy_słownik)
    for i in range(minimum, l+1): # słowa mają długość conajmniej 1
        for permutacja in permutations(nowa_wiadomość, i): # wszystkie możliwe kombinacje danej liczby liter
            słowo = "".join(permutacja) # tworzymy napis
            if słowo in nowy_słownik:
                rozwiązanie.add(słowo)
    return rozwiązanie

def funkcja(słownik, wiadomość):
    rozwiązanie = []
    nowy_słownik = new_słownik(słownik, wiadomość)
    nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)
    for słowo in nowy_słownik:
        if słowo in nowa_wiadomość:
            rozwiązanie.append(słowo)
    return len(rozwiązanie)  

#print(funkcja(słownik, wiadomość))

def iloveyousodamnmuch(słownik, wiadomość):
    rozwiązanie = []
    nowy_słownik = new_słownik(słownik, wiadomość)
    nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)
    #for słowo in nowy_słownik:
        #for pieprzona_litera in słowo: