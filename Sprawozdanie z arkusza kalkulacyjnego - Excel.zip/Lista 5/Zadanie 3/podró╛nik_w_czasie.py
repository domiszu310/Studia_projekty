from itertools import permutations

słownik = {'kalafior', 'rower', 'krowa', 'pieczarka',
           'prezydent', 'usa', 'pi', 'sigma', 'python', 
           'naleśniki'}

wiadomość = "uslppiapniepyrtswczehazdoyrkcnadvientjqlkjeogijpzxczx"

#napis = "abc"
#permutacje = permutations(napis, 1) # liczba to długość wypluwanego napisu - wszystkie możliwe permutacje jednoelementowe
#for perm in permutacje:
 #   print(''.join(perm))
#print(list(permutations(wiadomość, 3)))

def new_słownik(słownik, wiadomość): # funkcja wykreśla ze słownika słowa, które zawierają litery, których nie ma w wiadomości
    nowy = []
    for słowo in słownik:
        new = True # przypisujemy wartość logiczną
        for litera in słowo:
            if litera not in wiadomość: # sprawdzamy czy słowo spełnia warunek
                new = False
        if new is True:
            nowy.append(słowo)
    return nowy

#print(new_słownik(słownik, wiadomość)) # ['rower', 'pieczarka', 'usa', 'python', 'krowa', 'pi', 'prezydent']

def new_wiadomość(słownik, wiadomość): # funkcja wyrzuca z wiadomości litery, których nie zawierają słowa ze słownika
    nowa = ""
    for litera in wiadomość:
        for słowo in słownik:
            if litera in słowo:
                nowa += litera
                break
    return nowa

#print(new_wiadomość(słownik, wiadomość)) # uslppiapniepyrtswczehazdoyrkcnadientlkeogipzcz

def najkrótsze_słowo(słownik): # funkcja znajduje najkrótsze słowo w słowniku
    return min(len(słowo) for słowo in słownik)

def najdłuższe_słowo(słownik): # funkcja znajduje najkrótsze słowo w słowniku
    return max(len(słowo) for słowo in słownik)

#print(najkrótsze_słowo(słownik))

# trzeba wykreślić litery, które zostały już użyte do stworzenia słowa, ale tylko po jednej
# może coś z indeksowaniem???

def podróżnik_w_czasie(słownik, wiadomość): # funkcja znajduje słowa ze słownika w wiadomości
    rozwiązanie = []
    nowy_słownik = new_słownik(słownik, wiadomość)
    nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)
    minimum = najkrótsze_słowo(nowy_słownik)
    maksimum = najdłuższe_słowo(nowy_słownik)
    for i in range(minimum, maksimum+1): # słowa mają długość conajmniej 1
        for p in permutations(nowa_wiadomość, i): # wszystkie możliwe połaczenia danej liter i odpowiednią liczbą innych liter
            słowo = "".join(p) # tworzymy napis
            if słowo in nowy_słownik:
                rozwiązanie.append(słowo)
                użyte_litery = set(p)
                for litera in użyte_litery:
                     nowa_wiadomość = nowa_wiadomość.replace(litera, "", 1) # wykreślamy tylko jedno występnie litery
                nowy_słownik.remove(słowo)
    return len(rozwiązanie), rozwiązanie

print(podróżnik_w_czasie(słownik, wiadomość))

# można też wykluczać słowa ze słownika ze względu na kolejność liter w wiadmości np.:
    # "w" występuje przed jakimkolwiek "k" zatem "krowa" jest niemożliwa do skomponowania
    # "w" występuje przed jakimkolwiek "o" zatem "rower" jest niemożliwy do skomponowania
# po ręcznych obliczeniach wychodzi 5

#print(new_słownik(słownik, new_wiadomość(słownik, wiadomość))) # {'prezydent', 'rower', 'pi', 'python', 'krowa', 'usa', 'pieczarka'}
#print(new_wiadomość(new_słownik(słownik, wiadomość), wiadomość)) # usppiapniepyrtswczehazdoyrkcnadientkeoipzcz

#rozwiązanie = []
#for p in permutations(wiadomość, 3): # wszystkie możliwe połaczenia danej liter i odpowiednią liczbą innych liter
    #        słowo = "".join(p) # tworzymy napis
   #         if słowo in słownik:
  #             rozwiązanie.append(słowo)
   #             for litera in słowo:
 #                   wiadomość = wiadomość.replace(litera, "", 1)
#print(rozwiązanie)