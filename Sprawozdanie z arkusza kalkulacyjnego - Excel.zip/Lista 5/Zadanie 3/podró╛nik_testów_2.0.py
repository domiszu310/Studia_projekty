from itertools import permutations

słownik = {'kalafior', 'rower', 'krowa', 'pieczarka',
           'prezydent', 'usa', 'pi', 'sigma', 'python', 
           'naleśniki'}

wiadomość = "uslppiapniepyrtswczehazdoyrkcnadvientjqlkjeogijpzxczx"



def new_słownik(słownik, wiadomość): # funkcja wykreśla ze słownika słowa, które zawierają litery, których nie ma w wiadomości
    nowy = []
    for słowo in słownik:
        new = True # przypisujemy wartość logiczną
        for litera in słowo:
            if litera not in wiadomość: # sprawdzamy czy słowo spełnia warunek
                new = False
        if new is True:
            nowy.append(słowo)
    return nowy

#print(new_słownik(słownik, wiadomość))

def new_wiadomość(słownik, wiadomość):
    nowa = ""
    for litera in wiadomość:
        for słowo in słownik:
            if litera in słowo:
                nowa += litera
                break
    return nowa


def najkrótsze_słowo(słownik):
    najkrótsze = None
    l = float("inf")
    for słowo in słownik:
        if len(słowo) < l:
            l = len(słowo)
            najkrótsze = słowo
    return len(najkrótsze)

def funkcja(słownik, wiadomość):
    rozwiązanie = []
    nowy_słownik = new_słownik(słownik, wiadomość)
    nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)
    for słowo in nowy_słownik:
        if słowo in nowa_wiadomość:
            rozwiązanie.append(słowo)
    return rozwiązanie

def funkcja2(słownik, wiadomość):
    rozwiązanie = []
    nowy_słownik = new_słownik(słownik, wiadomość)
    nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)
    for słowo in nowy_słownik:
        if all(słowo.count(letter) <= nowa_wiadomość.count(letter) for letter in słowo):
            rozwiązanie.append(słowo)
    return rozwiązanie

#print(funkcja(słownik, wiadomość))

def znajdź_słowa(słownik, wiadomość):
    def dfs(wiadomość, pozostałe_litery, obecne_słowo, rozwiązanie):
        if obecne_słowo in słownik:
            rozwiązanie.add(obecne_słowo)
        if not pozostałe_litery:
            return
        for i in range(len(pozostałe_litery)):
            nowa_wiadomość = wiadomość + pozostałe_litery[i]
            nowe_litery = pozostałe_litery[:i] + pozostałe_litery[i+1:]
            dfs(nowa_wiadomość, nowe_litery, obecne_słowo + pozostałe_litery[i], rozwiązanie)

    rozwiązanie = set()
    dfs("", wiadomość, "", rozwiązanie)
    return rozwiązanie

#def funkcja_dla_wszystkich(słownik, wiadomość):
 #   rozwiązanie = []
  #  nowy_słownik = new_słownik(słownik, wiadomość)
   # nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)
    #for słowo in nowy_słownik:
     #   if all(słowo.count(letter) <= nowa_wiadomość.count(letter) for letter in słowo):
      #      rozwiązanie.append(słowo)
    #return rozwiązanie

#for word in słownik:
   # print(word, funkcja_dla_wszystkich({word}, wiadomość))


def funkcja_dla_wszystkich(słownik, wiadomość):
    rozwiązanie = []
    nowy_słownik = new_słownik(słownik, wiadomość)
    nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)
    for słowo in nowy_słownik:
        wiadmość_testowa = nowa_wiadomość # dla każdego słowa ze słownika będą wykreślane litery z wiadomości, żeby znaleźć to słowo
        dobre_słowo = True # wartość logiczna określająca, czy z danych liter da się stworzyć dane słowo
        for litera in słowo:
            if litera in wiadmość_testowa:
                index = wiadmość_testowa.index(litera) # nadajemy literze indeks, jeśli występuje w wiadomości
                wiadmość_testowa = wiadmość_testowa[index+1:] # usuwamy wszystkie litery przed literą o nadanym indeksie
            else:
                dobre_słowo = False
                break # pozwala na wyeliminowanie rowera i krowy
        if dobre_słowo:
            rozwiązanie.append(słowo)
    return len(rozwiązanie)

słownik = {'kalafior', 'rower', 'krowa', 'pieczarka',
           'prezydent', 'usa', 'pi', 'sigma', 'python',
           'naleśniki'}

wiadomość = "uslppiapniepyrtswczehazdoyrkcnadvientjqlkjeogijpzxczx"

print(funkcja_dla_wszystkich(słownik, wiadomość))


def znajdź_słowa8(słownik, wiadomość):
    wynik = set()
    nowy_słownik = new_słownik(słownik, wiadomość)
    nowa_wiadomość = new_wiadomość(nowy_słownik, wiadomość)

    def dfs(index, słowo):
        if słowo in nowy_słownik:
            wynik.add(słowo)
        if index >= len(nowa_wiadomość):
            return
        for i in range(index + 1, len(nowa_wiadomość) + 1):
            podciąg = nowa_wiadomość[index:i]
            if podciąg in nowy_słownik:
                dfs(i, słowo + podciąg)

    dfs(0, "")
    return wynik

#print(znajdź_słowa8(słownik, wiadomość))