# Uzupełnij kod funkcji tak, aby zwracał wiadomość zaszyfrowaną za pomocą szyfru Cezara.
# Możesz założyć, że wiadomość składa się tylko z wielkich liter alfabetu angielskiego.

# "a" to 97, "z" to 122, czyli liter jest 25

def koduj(napis, klucz=1): # klucz to o ile ma być przesunięte
    nowy_napis = []
    litery = list(napis.upper()) # przyjmuje niezależnie od wielkości liter, ale zwraca duże litery
    for i in litery:
        if i.isalpha(): # sprawdzamy czy i jest literą
            numer = ord(i) - ord("A") # dzięki temu litery będą w zakresie od 0 do 25
            nowy_numer = (numer + klucz) % 26 # dla 'z' przy przesunięciu o 1 musi zwracać a
            nowa_litera = chr(nowy_numer + ord("A"))
            nowy_napis.append(nowa_litera)
        else:
            raise ValueError("Napis zawiera znaki inne niż litery.") 
    return "".join(nowy_napis)

#print(koduj("kot", klucz=2)) # przesunięcie o 2, czyli powinno być "OCOC"

#print(koduj("zlew", klucz=1)) # przesunięcie o 1, czyli powinno być "AMFX"