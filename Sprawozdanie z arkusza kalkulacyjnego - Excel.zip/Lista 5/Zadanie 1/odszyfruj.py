# Złamanie szyfru może polegać na uszeregowaniu odkodowanych wiadomości od najbardziej prawdopodobnej do najmniej prawdopodobnej.
# Procedura może wyglądać następująco:
    # dla każdego klucza K wykonaj próbę odkodowania wiadomości,
    # dla każdej odkodowanej wiadomości wyznacz częstość występowania liter,
    # dla każdej częstości występowania liter, wyznacz podobieństwo tej częstości do zadanej dla języka,
    # posortuj klucze po mierze podobieństwa.

# Napisz funkcję, która spróbuje odgadnąć klucz na podstawie wiadomości i informacji, że jest to wiadomość po polsku
# (tylko wielkie znaki z zakresu A–Z, znaki takie jak Ą zamienione są na wersję bez akcentów).

# kluczy może być od 1 do 25 (0 nic nie zmienia, więc możemy je pominąć)
# dla każdego klucza próbujemy odszyfrować wiadomość, potem analizujemy częstotliwość występowania lister w tej wiadomości
# porównujemy częstotliwość do wartości ze słownika dla języka polskiego
# korzystając z funkcji porównaj, porównujemy dwa słowniki, następnie sortujemy w zależności od prawdopodobieństwa
# funkcja zwraca najlepszy klucz - największa częstotliwość

from dekoduj import dekoduj

freq = {
  'A': 0.099,  'B': 0.0147, 'C': 0.0436, 'D': 0.0325, 'E': 0.0877, 'F': 0.003,  'G': 0.0142,
  'H': 0.0108, 'I': 0.0821, 'J': 0.0228, 'K': 0.0351, 'L': 0.0392, 'M': 0.028,  'N': 0.0572,
  'O': 0.086,  'P': 0.0313, 'Q': 0.0014, 'R': 0.0469, 'S': 0.0498, 'T': 0.0398, 'U': 0.025,
  'V': 0.004,  'W': 0.0465, 'X': 0.0002, 'Y': 0.0376, 'Z': 0.0653
}

def porównaj(freq1, freq2):
    delta = 0
    for litera, częstość in freq1.items():
        if litera not in freq2:
            delta += częstość
        else:
            delta += abs(częstość - freq2[litera])
    for litera, częstość in freq2.items():
        if litera not in freq1:
            delta += częstość
    return delta

def odszyfruj(napis):
    porównane = {}
    for K in range(1, 26):
        odkodowana = dekoduj(napis, klucz=K) # dekodujemy wiadomość
        freq_odkodowana = {} # tworzymy słownik, którego kluczami będą wartości K, natomiast wartościami liczba wystąpień danej litery
        for i in odkodowana:
            if i.isalpha():
                i = i.upper()
                if i in freq_odkodowana:
                    freq_odkodowana[i] += 1
                else:
                    freq_odkodowana[i] = 1

        l = len(odkodowana)
        for litera, freq_litera in freq_odkodowana.items():
            freq_odkodowana[litera] = freq_litera / l
        
        porównanie = porównaj(freq, freq_odkodowana)
        porównane[K] = porównanie

    best_klucz = min(porównane, key=porównane.get) # zwraca klucz ze słownika porównane, dla którego częstotliwość jest najmniejsza
    wiadomość = dekoduj(napis, klucz=best_klucz)
    return wiadomość, best_klucz

#print(odszyfruj("OCOC")) # powinno być MAMA i klucz = 2