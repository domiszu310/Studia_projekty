# Uzupełnij kod funkcji tak, aby zwracał wiadomość odszyfrowaną za pomocą szyfru Cezara.
# Możesz założyć, że wiadomość składa się tylko z wielkich liter alfabetu angielskiego.
# Pomyśl, czy potrafisz sprytnie wykorzystać rozwiązanie poprzedniego podpunktu?

# przesuwanie w prawo o x znaków, to przesuwanie w lewo o -x znaków

from koduj import koduj

def dekoduj(napis, klucz=1):
    return koduj(napis, klucz=(-1)*klucz)

#print(dekoduj("kot", klucz=2))

#print(dekoduj("amfx", klucz=1))
