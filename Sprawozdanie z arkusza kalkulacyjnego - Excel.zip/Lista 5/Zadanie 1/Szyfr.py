# Szyfr Cezara to prosty sposób szyfrowania wiadomości. Polega on na przesunięciu liter. Ustalamy, że znany jest klucz K∈{1,…,25},
# następnie każdą literę zamieniamy na literę o K większą.
    # Przykładowo, jeśli K = 2, litera A przekształcona zostanie na C, natomiast Z na B (wykonujemy operację modulo liczba liter).

c = 'c'
n = ord(c) - ord('a') # 99 - 97 = 2, ord() zwraca liczbę całkowitą reprezentującą daną literę
n += 2 # 2 + 2 = 4
#print(n) # 4

m = chr(ord('a') + n) # 97 + 4 = 101, chr() zwraca literę reprezentowaną przez daną liczbę całkowitą
#print(m)

#print(ord("O") - 2)
#print(chr(77))

def koduj(napis, klucz=1): # klucz to o ile ma być przesunięte
    nowy_napis = []
    litery = list(napis.upper()) # przyjmuje niezależnie od wielkości liter, ale zwraca duże litery
    for i in litery:
        if i.isalpha():
            numer = ord(i) - ord("A") # dzięki temu litery będą w zakresie od 0 do 25
            nowy_numer = (numer + klucz) % 26 # dla 'z' przy przesunięciu o 1 musi zwracać a
            nowa_litera = chr(nowy_numer + ord("A"))
            nowy_napis.append(nowa_litera)
        else:
            raise ValueError("Napis zawiera znaki inne niż litery.")  
    return "".join(nowy_napis)

def dekoduj(napis, klucz=1):
    return koduj(napis, klucz=(-1)*klucz)

freq = {
  'A': 0.099,  'B': 0.0147, 'C': 0.0436, 'D': 0.0325, 'E': 0.0877, 'F': 0.003,  'G': 0.0142,
  'H': 0.0108, 'I': 0.0821, 'J': 0.0228, 'K': 0.0351, 'L': 0.0392, 'M': 0.028,  'N': 0.0572,
  'O': 0.086,  'P': 0.0313, 'Q': 0.0014, 'R': 0.0469, 'S': 0.0498, 'T': 0.0398, 'U': 0.025,
  'V': 0.004,  'W': 0.0465, 'X': 0.0002, 'Y': 0.0376, 'Z': 0.0653
}

def porównaj(freq1, freq2):
    delta = 0
    for litera, częstość in freq1.items():
        if litera not in freq2:
            delta += częstość
        else:
            delta += abs(częstość - freq2[litera])
    for litera, częstość in freq2.items():
        if litera not in freq1:
            delta += częstość
    return delta

def odszyfruj(napis):
    porównane = {}
    for K in range(1, 26):
        odkodowana = dekoduj(napis, klucz=K) # dekodujemy wiadomość
        freq_odkodowana = {} # tworzymy słownik, którego kluczami będą wartości K, natomiast wartościami liczba wystąpień danej litery
        for i in odkodowana:
            if i.isalpha():
                i = i.upper()
                if i in freq_odkodowana:
                    freq_odkodowana[i] += 1
                else:
                    freq_odkodowana[i] = 1
        porównanie = porównaj(freq, freq_odkodowana)
        porównane[K] = porównanie

    best_klucz = min(porównane, key=porównane.get) # zwraca klucz ze słownika porównane, dla którego częstotliwość jest największa
    wiadomość = dekoduj(napis, klucz=best_klucz)
    return wiadomość, best_klucz

L = 'OCOC'
print(odszyfruj(L)) # powinno zwracać MAMA