def LCS(napis1, napis2): # najdłuższy wspólny podnapis
    m, n = len(napis1), len(napis2)
    L = [[0]*(n+1) for _ in range(m+1)]
    for i in range(n):
        for j in range(m):
            if napis1[j] == napis2[i]:
                L[j+1][i+1] = L[j][i]+1
    M = [max(wiersz) for wiersz in L]
    najdłuższy = max(M)
    if not najdłuższy:
        return []
    wyniki = []
    for j in range(1, m+1):
        if M[j] == najdłuższy:
            wyniki.append(napis1[j-najdłuższy:j])
    return list(set(wyniki))

#print(LCS("kotek", "bojkot")) # kot

def levenshtein_test(napis1, napis2): # ile zmian, żeby napis1 == napis2
    m, n = len(napis1), len(napis2)
    L = [[0]*(n+1) for _ in range(m+1)] # tworzymy tablicę - macierz - na elementy

    # 1. wiersz i kolumna macierzy, to liczby od 0 do len(napis)
    for i in range(n+1): # 1. wiersz
        L[0][i] = i # napis2
    for j in range(1, m+1): # 1. kolumna (0 jest już uzupełnione)
        L[j][0] = j # napis1
    
    # 2. wiersz i kolumna macierzy, to liczby z 1. +1
    for i in range(1, m+1):
        for j in range(1, n+1):
            if napis1[i-1] == napis2[j-1]:
                zmiana = 0
            else: # jeśli napis1[j] != napis2[i], to wykonujemy jedną zmianę
                zmiana = 2
            # dla wybranego "miejsca" bierzy minimum z liczb nad nią, na lewo i po skosie
            L[i][j] = min(L[i][j-1]+1, L[i-1][j]+1, L[i-1][j-1] + zmiana)
    
    return L[m][n]

#print(levenshtein_test("book", "back"))