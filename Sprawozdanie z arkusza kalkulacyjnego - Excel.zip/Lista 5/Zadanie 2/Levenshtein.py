# Napisz funkcję 'levenshtein(napis1, napis2)', która jako argumenty będzie przyjmować dwa napisy
# i obliczać będzie odległość Levenshteina między nimi.

# Odległość Levenshteina - ile zmian trzeba dokonać, żeby napis1 == napis2.

# Wzorujemy się na funkcji LCS z wykładu 6.

def levenshtein(napis1, napis2): # ile zmian, żeby napis1 == napis2
    # usuwamy białe znaki
    napis1 = napis1.replace(" ", "")
    napis2 = napis2.replace(" ", "")

    m, n = len(napis1), len(napis2)
    L = [[0]*(n+1) for _ in range(m+1)] # tworzymy tablicę - macierz - na elementy

    # 1. wiersz i kolumna macierzy, to liczby od 0 do len(napis)
    for i in range(n+1): # 1. wiersz
        L[0][i] = i # napis2
    for j in range(1, m+1): # 1. kolumna (0 jest już uzupełnione)
        L[j][0] = j # napis1
    
    # 2. wiersz i kolumna macierzy, to liczby z 1. +1
    for i in range(1, m+1):
        for j in range(1, n+1):
            if napis1[i-1] == napis2[j-1]:
                zmiana = 0
            else: # jeśli napis1[j] != napis2[i], to wykonujemy jedną zmianę
                zmiana = 2
            # dla wybranego "miejsca" bierzy minimum z liczb nad nią, na lewo i po skosie
            L[i][j] = min(L[i][j-1]+1, L[i-1][j]+1, L[i-1][j-1] + zmiana)
    
    return L[m][n]

#print(levenshtein("book a", "back")) # 4
#print(levenshtein("kot Ali", "pies Olka")) # 12