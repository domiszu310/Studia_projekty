# Napisz funkcję 'guess(napis, lista)', w której 'napis' to pewien napis, natomiast 'lista' to lista napisów.
# Funkcja powinna zwracać wszystkie napisy z listy, dla których odległość edycyjna (L) od tekstu w zmiennej 'napis' jest najmniejsza.

from Levenshtein import levenshtein

def guess(napis, lista):
    odległość = {}
    for n in lista:
        odległość[n] = levenshtein(n, napis)
    min_odległość = min(odległość.values())
    return [n for n, d in odległość.items() if d == min_odległość]

#print(guess("Ala", ["Olek", "book a", "back"]))

L = ["Ala", "Olek", "book a", "back", "zlew"]
napis = "kot"
#print(guess(napis, L)) # Olek, back