from collections import Counter

L = [9,7,7,1,1,7,8]
#L.sort()
#print(Counter(L)) # COUNTER NIE ZWRACA POSORTOWANYCH ELEMENTÓW !!!!!!!

def zliczanie(lista, klucze): # klucze to wartości, które mogą występować na liście np. lista L ma klucze = range(1, 10)
    l = len(lista)
    wystąpienia = {k : 0 for k in klucze} # początkowo liczba wystąpień każdego elementu z kluczy wynosi 0
    for elem in lista: # dla każdego elementu w liście
        wystąpienia[elem] += 1 # jeśli element z kluczy jest w liście to do jego liczby wystąpień dodajemy 1, słownik[klucz1] = wartość1
    pozycje = {} # pozycje = {klucze : pierwsze wystąpienie klucza w posortowanej liście}
    liczba_wystąpień = 0
    for k in klucze:
        pozycje[k] = liczba_wystąpień # dla każdej wartości k mamy początkowo liczbę wystąpień równą 0
        liczba_wystąpień += wystąpienia[k] # do liczby wystąpień dodajemy odpowiadającą k wartość ze słownika
    posortowana = [0*l]
    #for k in klucze:
        #for elem in lista:
           # liczba = lista[k]
          #  pozycja = pozycje[liczba]
         #   posortowana[pozycja]
        #miejsce = wystąpienia[elem] # miejsce na liście to np. L[1] czyli drugi element z listy
            
    return pozycje

print(zliczanie(L, range(1, 10)))