import numpy as np
import matplotlib.pyplot as plt
from Czas_sortowanie import zmierz_sortowanie
from sortowanie_zliczanie import sortowanie_zliczanie
from Sortowanie import sortowanie_bąbelkowe, sortowanie_scalanie, sortowanie_wstawianie, sortowanie_wybieranie
from random import choice

klucze=range(1,10)
lista_tysiąca=[choice(klucze) for n in range(11)]

numery=list(range(1,7))
czas_kodu=[0]*6

czas_kodu[0]=(zmierz_sortowanie(lambda lista: sortowanie_zliczanie(lista,klucze), lista_tysiąca))
czas_kodu[1]=(zmierz_sortowanie(lambda lista: sortowanie_bąbelkowe(lista), lista_tysiąca))
czas_kodu[2]=(zmierz_sortowanie(lambda lista: sortowanie_wstawianie(lista), lista_tysiąca))
czas_kodu[3]=(zmierz_sortowanie(lambda lista: sortowanie_wybieranie(lista), lista_tysiąca))
czas_kodu[4]=(zmierz_sortowanie(lambda lista: sortowanie_scalanie(lista), lista_tysiąca))
czas_kodu[5]=(zmierz_sortowanie(lambda lista: lista.sort(), lista_tysiąca))

print(czas_kodu)
plt.scatter(numery,czas_kodu)
plt.show()