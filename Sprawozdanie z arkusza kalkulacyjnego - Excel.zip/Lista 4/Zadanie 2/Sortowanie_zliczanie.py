# Załóżmy, że mamy listę lista, której elementy przyjmują wartości z posortowanej listy klucze. Algorytm przebiega następująco:
    # 1. Dla każdego elementu listy 'klucze' obliczamy liczbę wystąpień tego elementu w liście 'lista'.
    # 2. Otrzymujemy słownik 'wystapienia', którego kluczami są elementy listy 'klucze' a wartościami liczba wystąpień każdego klucza
        # w liście 'lista'. Na podstawie słownika wystapienia możemy określić ile razy i na jakich miejscach w posortowanej liście
        # pojawią się poszczególne klucze.
    # 3. Tworzymy słownik 'pozycje' o kluczach z listy 'klucze' i wartościach będących pierwszymi wystąpieniami danego klucza 
        # w posortowanej liście (wartość dla każdego klucza jest równa sumie wartości dla wszystkich kluczy go poprzedzających).
    # 4. Tworzymy pustą listę 'posortowana' o tej samej długości co 'lista'. Iterując się po elementach 'elem' oryginalnej listy 'lista',
        # wpisujemy każdy element w miejscu o indeksie równym 'wystapienia[elem]' i zwiększamy 'wystapienia[elem]' o 1.

# Napisz funkcję sortowanie_zliczanie(lista, klucze), która posortuje listę "lista" o elementach przyjmujących wartości z listy klucze
    # za pomocą podanego algorytmu. Postaraj się, aby napisana funkcja miała optymalną złożoność obliczeniową
    # (na przykład używanie metody .count() z osobna dla każdego klucza nie jest optymalne).
    # Możesz założyć, że podana przez użytkownika lista "lista" zawiera wyłącznie elementy o wartościach z listy klucze.

def sortowanie_zliczanie(lista, klucze): # klucze to wartości, które mogą występować na liście np. lista L ma klucze = range(1, 10)
    l = len(lista)

    # 1. i 2.
    wystąpienia = {k : 0 for k in klucze} # początkowo liczba wystąpień każdego elementu z kluczy wynosi 0
    for elem in lista: # dla każdego elementu w liście
        wystąpienia[elem] += 1 # jeśli element z kluczy jest w liście to do jego liczby wystąpień dodajemy 1, słownik[klucz1] = wartość1

    # 3.
    pozycje = {} # pozycje = {klucze : pierwsze wystąpienie klucza w posortowanej liście}
    liczba_wystąpień = 0
    for k in klucze:
        pozycje[k] = liczba_wystąpień # dla każdej wartości k mamy początkowo liczbę wystąpień równą 0
        liczba_wystąpień += wystąpienia[k] # do liczby wystąpień dodajemy odpowiadającą k wartość ze słownika

    # 4.
    posortowana = [0]*l
    for elem in lista:
        pozycja = pozycje[elem] # pozycja na posortowanej liście
        posortowana[pozycja] = elem
        pozycje[elem] += 1
            
    return posortowana

#L = [9, 7, 7, 1, 1, 7, 8]
#print(sortowanie_zliczanie(L, range(1, 10)))

#wystąpienia = {1: 2, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 3, 8: 1, 9: 1}
#pozycje = {1: 0, 2: 2, 3: 2, 4: 2, 5: 2, 6: 2, 7: 2, 8: 5, 9: 6}

#L_posortowana = [1, 1, 7, 7, 7, 8, 9]