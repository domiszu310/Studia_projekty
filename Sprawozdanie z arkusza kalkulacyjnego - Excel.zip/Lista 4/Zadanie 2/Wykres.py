import numpy as np
import matplotlib.pyplot as plt
from random import choice
from Czas_sortowanie import zmierz_sortowanie
from Sortowanie_zliczanie import sortowanie_zliczanie
from Sortowanie import sortowanie_bąbelkowe, sortowanie_scalanie, sortowanie_wstawianie, sortowanie_wybieranie

L = [choice(range(10)) for i in range(1000)] # daje listę elementów z zakresu 0 do 9 długości 10

klucze = list(range(10))

X = list(range(1, 7)) # będzie 6 punktów - po jednym dla każdej funkcji
sortowanie_czas = [0]*6

sortowanie_czas[0]=(zmierz_sortowanie(lambda lista: sortowanie_zliczanie(lista,klucze), L))
sortowanie_czas[1]=(zmierz_sortowanie(lambda lista: sortowanie_bąbelkowe(lista), L))
sortowanie_czas[2]=(zmierz_sortowanie(lambda lista: sortowanie_wstawianie(lista), L))
sortowanie_czas[3]=(zmierz_sortowanie(lambda lista: sortowanie_wybieranie(lista), L))
sortowanie_czas[4]=(zmierz_sortowanie(lambda lista: sortowanie_scalanie(lista), L))
sortowanie_czas[5]=(zmierz_sortowanie(lambda lista: lista.sort(), L))

kolory = ['red', 'blue', 'green', 'yellow', 'orange', 'black']

plt.scatter(X, sortowanie_czas, c = kolory) # łączy dwie listy i rysuje wykres punktowy (Ox, Oy)
plt.xticks(X, ['zliczanie', 'bąbelkowe', 'wstawianie', 'wybieranie', 'scalanie', '.sort()'])
plt.xlabel('sortowanie')
plt.ylabel('czas')
plt.xlim((0, 7))
plt.yticks(np.arange(0, 0.05, 0.005))
plt.show()