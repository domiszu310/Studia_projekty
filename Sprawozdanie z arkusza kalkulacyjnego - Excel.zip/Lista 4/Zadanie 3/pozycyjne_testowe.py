def nowe_sortowanie_zliczanie(lista, klucze, k): # klucze to wartości, które mogą występować na liście np. lista L ma klucze = range(1, 10)
    l = len(lista)

    # 1. i 2.
    wystąpienia = {klucz : 0 for klucz in klucze} # początkowo liczba wystąpień każdego elementu z kluczy wynosi 0
    for elem in lista: # dla każdego elementu w liście
        if elem >= 10**k: # sprawdzamy czy element ma cyfrę na podanym miejscu k
            cyfra = (elem // 10**k)%10 # obliczamy cyfrę konkretnego miejsca znaczącego
        else:
            cyfra = 0 # jeśli mamy k = 3 i liczbę 970, to wtedy wstawiamy 0, żeby była traktowana jako mniejsza
        wystąpienia[cyfra] += 1

    # 3.
    pozycje = {} # pozycje = {klucze : pierwsze wystąpienie klucza w posortowanej liście}
    liczba_wystąpień = 0
    for klucz in klucze:
        pozycje[klucz] = liczba_wystąpień # dla każdej wartości k mamy początkowo liczbę wystąpień równą 0
        liczba_wystąpień += wystąpienia[klucz] # do liczby wystąpień dodajemy odpowiadającą k wartość ze słownika

    # 4.
    posortowana = [0]*l
    for elem in lista:
        if elem >= 10**k: # sprawdzamy czy element ma cyfrę na podanym miejscu k
            cyfra = (elem // 10**k)%10 # obliczamy cyfrę konkretnego miejsca znaczącego
        else:
            cyfra = 0 # jeśli mamy k = 3 i liczbę 970, to wtedy wstawiamy 0, żeby była traktowana jako mniejsza
        pozycja = pozycje[cyfra] # pozycja na posortowanej liście
        posortowana[pozycja] = elem
        pozycje[cyfra] += 1
    
    return posortowana

def max_cyfra(lista): # bierze listę i sortuje ją po podanej liczbie k (jedności, dziesiątki, setki...)
    l = 0
    for i in lista:
        string = str(i)
        długość = len(string)
        if długość > l:
            l = długość
    return l

#print(max_cyfra([112, 354, 1000]))

def sortowanie_pozycyjne(lista):
    # klucze będą na pewno od 0 do 9
    # k = k(n//10**k)%10
    for liczba in lista: # sprawdzenie, czy liczby są naturalne
        if liczba < 0:
            raise ValueError("Na liście znajdują się liczby ujemne.")
    
    znacząca = max_cyfra(lista) # maksymalna cyfra jedności, dziesiątek, setek...

    lista_sort = lista
    i = 0
    while i < znacząca: # cyfry znaczące 0 - jedności, 1 - dziesiątki, 2 - setki..., skoro zero to jedności, to i < znacząca
        lista_sort = nowe_sortowanie_zliczanie(lista_sort, klucze=list(range(10)), k=i) # TU JEST PROBLEM
        i += 1
    return lista_sort

L = [970, 7001, 1, 11, 47, 82]
print(sortowanie_pozycyjne(L))

# wystąpienia = {0: 5, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 1, 8: 0, 9: 0}
# pozycje = {0: 5, 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 6, 8: 6, 9: 6}

#print(nowe_sortowanie_zliczanie(L, klucze=list(range(10)), k = 0)) # [970, 7001, 1, 11, 82, 47]
#print(nowe_sortowanie_zliczanie(L, klucze=list(range(10)), k = 1)) # [7001, 1, 11, 47, 970, 82]
#print(nowe_sortowanie_zliczanie(L, klucze=list(range(10)), k = 2)) # [7001, 1, 11, 47, 82, 970]
#print(nowe_sortowanie_zliczanie(L, klucze=list(range(10)), k = 3)) # [970, 1, 11, 47, 82, 7001]