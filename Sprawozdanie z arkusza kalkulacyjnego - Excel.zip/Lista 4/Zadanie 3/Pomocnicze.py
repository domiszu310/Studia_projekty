def nowe_sortowanie_zliczanie(lista, klucze, k): # klucze to wartości, które mogą występować na liście np. lista L ma klucze = range(1, 10)
    l = len(lista)

    # 1. i 2.
    wystąpienia = {klucz : 0 for klucz in klucze} # początkowo liczba wystąpień każdego elementu z kluczy wynosi 0
    for elem in lista: # dla każdego elementu w liście
        if elem >= 10**k: # sprawdzamy czy element ma cyfrę na podanym miejscu k
            cyfra = (elem // 10**k)%10 # obliczamy cyfrę konkretnego miejsca znaczącego
        else:
            cyfra = 0 # jeśli mamy k = 3 i liczbę 970, to wtedy wstawiamy 0, żeby była traktowana jako mniejsza
        wystąpienia[cyfra] += 1

    # 3.
    pozycje = {} # pozycje = {klucze : pierwsze wystąpienie klucza w posortowanej liście}
    liczba_wystąpień = 0
    for klucz in klucze:
        pozycje[klucz] = liczba_wystąpień # dla każdej wartości k mamy początkowo liczbę wystąpień równą 0
        liczba_wystąpień += wystąpienia[klucz] # do liczby wystąpień dodajemy odpowiadającą k wartość ze słownika

    # 4.
    posortowana = [0]*l
    for elem in lista:
        if elem >= 10**k: # sprawdzamy czy element ma cyfrę na podanym miejscu k
            cyfra = (elem // 10**k)%10 # obliczamy cyfrę konkretnego miejsca znaczącego
        else:
            cyfra = 0 # jeśli mamy k = 3 i liczbę 970, to wtedy wstawiamy 0, żeby była traktowana jako mniejsza
        pozycja = pozycje[cyfra] # pozycja na posortowanej liście
        posortowana[pozycja] = elem
        pozycje[cyfra] += 1
    
    return posortowana

def max_cyfra(lista): # bierze listę i sortuje ją po podanej liczbie k (jedności, dziesiątki, setki...)
    l = 0
    for i in lista:
        string = str(i)
        długość = len(string)
        if długość > l:
            l = długość
    return l

#print(max_cyfra([112, 354, 1000]))