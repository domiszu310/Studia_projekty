# Sortowanie pozycyjne (radix sort) jest algorytmem sortowania list liczb wymiernych,
 # poprzez iteracyjne sortowanie ich na podstawie ich kolejnych cyfr.

# Zmodyfikuj napisaną w zadaniu 2 funkcję 'sortowanie_zliczanie(lista, klucze=list(range(10)))' tak, aby sortowała listę liczb naturalnych
 # na podstawie k-tej cyfry znaczącej. Użyj jej do napisania funkcji 'sortowanie_pozycyjne(lista)',
 # która posortuje listę 'lista' zawierającą liczby naturalne na podstawie kolejnych cyfr znaczących
 # (zaczynając od cyfry jedności) zmodyfikowaną metodą sortowania przez zliczanie, aż do wyczerpania się cyfr znaczących
 # (np. kiedy największa liczba na liście jest 5-cyfrowa, to powinno zostać wykonane 5 sortowań po każdej cyfrze znaczącej).

from Pomocnicze import nowe_sortowanie_zliczanie, max_cyfra

def sortowanie_pozycyjne(lista):
    # klucze będą na pewno od 0 do 9
    # k = k(n//10**k)%10
    for liczba in lista: # sprawdzenie, czy liczby są naturalne
        if liczba < 0:
            raise ValueError("Na liście znajdują się liczby ujemne.")
    
    znacząca = max_cyfra(lista) # maksymalna cyfra jedności, dziesiątek, setek...

    lista_sort = lista
    i = 0
    while i < znacząca: # cyfry znaczące 0 - jedności, 1 - dziesiątki, 2 - setki..., skoro zero to jedności, to i < znacząca
        lista_sort = nowe_sortowanie_zliczanie(lista_sort, klucze=list(range(10)), k=i)
        i += 1
    return lista_sort

#L = [970, 7001, 1, 11, 47, 82]
#print(sortowanie_pozycyjne(L))