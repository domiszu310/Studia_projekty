# Para (l_k, l_m) jest inwersją, jeśli k < m, ale l_k > l_m.
# Napisz program, który dla zadanej listy różnych elementów, zwróci listę par wszystkich inwersji w tej liście.
    # Np. jeśli lista to L = [1, 5, 2, -1], inwersje na tej liście to: [(1, -1), (5, 2), (5, -1), (2, -1)].

def inwersja(L):
    l = len(L) # liczba elementów na liście, gdzie indeksy na liście są od 0 do l-1
    pary = []
    for k in range(0, l): # mamy zakres od 0 do l-1, bo takie są indeksy na liście
        for m in range(0, l):
            if k < m and L[k] > L[m]: # dla mniejszego indeksu mamy większą liczbę
                pary.append((L[k], L[m]))
    return pary

L = [1, 5, 2, -1]
print(inwersja(L))