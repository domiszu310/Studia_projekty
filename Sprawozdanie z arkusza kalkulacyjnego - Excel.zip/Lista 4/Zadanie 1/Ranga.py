# Rangą elementu l_i jest jego indeks w posortowanej liście.
# Napisz program, który dla zadanej listy różnych elementów, zwróci listę rang poszczególnych elementów.
    # Przykładowo, jeśli lista to L = [1, 5, 2, -1], po posortowaniu otrzymujemy listę S = [−1, 1, 2, 5].
        # Wobec tego liczbie 1 odpowiada ranga 1 (druga na posortowanej liście), liczbie 5 ranga 3 (ostatnia na posortowanej liście),
        # liczbie 2 odpowiada ranga 2, liczbie −1 odpowiada ranga 0. Oznacza to, że lista rang elementów listy L to R = [1, 3, 2, 0].

def ranga(L):
    R = []
    l = len(L)
    indeks = list(range(0, l))
    zip1 = list(zip(L, indeks)) # wystarczy zzipować listę L z listą indeksów od 0 do l-1
    zip1.sort() # sortujemy elementy, wtedy otrzymamy kolejność oryginalnych indeksów na posortowanej liście
    _, indeks2 = zip(*zip1) # otrzymujemy dwie krotki postaci (posortowane elementy) (indeksy oryginalej listy)
    zip2 = list(zip(list(indeks2), indeks)) # lista indeks2 jest tej samej długości co lista L, więc możemy skorzystać z listy indeks
    zip2.sort() # sortujemy i otrzymujemy rangi poszczególnych elementów na liście L
    _, R = zip(*zip2)
    return list(R)

L = [1, 5, 2, -1]
print(ranga(L))