# Władca pewnego królestwa miał k > 0 dzieci.
# Postanowił podzielić swoją ziemię pomiędzy nich tak, aby nie było kłótni i aby cała ziemia została rozdzielona.
# Ustalił, że ewentualny spadek koniecznie musi przyjąć najstarszy syn,
# natomiast każde kolejne dziecko może przyjąć lub odmówić udziału w podziale majątku.
# Po ustaleniu kto uczestniczy w podziale, każdy z partycypujących potomków ma otrzymać tyle samo ziemi.
    # Na ile części (co najmniej) król musi podzielić swoją ziemię, aby w żadnej sytuacji nie było problemów z podziałem?
# Wiemy, że żadne z dzieci nie może otrzymać kawałka wydzielonej części, ponieważ wypowie wojnę bratu lub siostrze, z którą miałoby go dzielić.

# Napisz funkcję przyjmującą k jako argument i zwracającą liczbę działek.
    # Trzeba napisać funkcję, która pozwoli obliczyć najmniejszą wspólną wielokrotność (NWW) liczb np. dla 4 dzieci liczby to 1, 2, 3, 4

from Euklides import xgcd

def NWW(k):
    if k <= 0:
        raise ValueError('Nie może mieć mniej niż jedno dziecko.')
    gcd, _, _ = xgcd(1, k)
    wynik = 1 # element neutralny mnożenia
    for i in range(1, k+1):
        wynik = (wynik * i)//gcd # za każdym razem zmieniamy wynik
    return wynik

#print(NWW(3))
# w przypadku 3, mamy:
    # NWD 1 i 3 czyli 1
    # i w przedziale (1, 4) ---> wynik = 1*1/1 = 1, wynik = 1*2/1 = 2, wynik = 2*3/1 = 6
    # pętla się kończy, zwracamy 6

print(NWW(0))