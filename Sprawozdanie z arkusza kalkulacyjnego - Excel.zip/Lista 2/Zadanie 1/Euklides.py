# rozszerzony algorytm Euklidesa

# równanie diofantyczne ax + by = c

def xgcd(a, b): # zwraca (największy współny dzielnik, x, y), rozwiązuje równanie postaci ax + by = gcd{a, b}
    if b==0:
        return (a, 1, 0)
    else:
        (gcd, x_prim, y_prim) = xgcd(b, a%b)
        return (gcd, y_prim, x_prim-a//b*y_prim)

#print(xgcd(5, 8)) # zwraca (1, -3, 2)

def gcd_loop(a, b):
    for n in range(min(a, b), 1, -1):
        if a%n==0 and b%n==0:
            return n
    return 1

#print(gcd_loop(8, 12))
#print(xgcd(18, 16))
#print(int(4.13))
