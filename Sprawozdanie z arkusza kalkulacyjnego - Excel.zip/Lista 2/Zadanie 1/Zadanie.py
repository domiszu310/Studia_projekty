# Skoczek pustynny Alfred zakończył imprezę i wyszedł z baru.
# W tym stanie potrafi wykonywać krótkie skoki długości 84 centymetry lub długie długości 2.28 metra (228 centymetrów).
# Porusza się dokładnie w linii prostej, kierując się prosto do celu lub z powrotem prosto do baru (widać nie może się zdecydować).
# Nasz skoczek pustynny do domu ma 430 centymetrów.
# Alfred ma też inną opcję - może nocować u kumpla, tłustogona afrykańskiego imieniem Horacy. Horacy mieszka 432 centymetry od baru.
    # Czy w tym stanie Alfred może trafić do domu lub do kolegi, czy będzie musiał spać pod gołym niebem?
    # Jeśli nocuje pod dachem, to gdzie i w ilu co najmniej skokach tam trafi?

# Bar to 0, dom Alfreda to 430, natomiast Horacego to 432 lub -432
# Można stworzyć dwa równania diofantyczne 84x + 228y = 430 oraz 84x + 228y = 432 albo 84x + 228y = -432
# Można trochę zmodyfikować funkcję z diofantyczne_nieujemne, by zwraca również ujemne rozwiązania

from diofantyczne_rozwiązanie import diofantyczne_rozwiązanie
from diofantyczne_ma_rozwiązanie import diofantyczne_ma_rozwiązanie
from Euklides import xgcd

def alfred_ma_problem(a, b, c): # można zrobić dla ustalony a i b, bo w każdym przypadku są takie same
    S = set()
    if diofantyczne_rozwiązanie(a, b, c) is not None:
        x, y = diofantyczne_rozwiązanie(a, b, c)
        gcd, _, _ = xgcd(a, b) # _ pomijamy zmienną
        m = x + b//gcd
        n = y - a//gcd
        if diofantyczne_ma_rozwiązanie(a, b, c) is True:
            for k in range(min(m, n), max(m, n)+1): # range przyjmuje tylko wartości całkowite, więc nie musi być int
                x_k = x + (b//gcd) * k
                y_k = y - (a//gcd) * k
                S.add((x_k, y_k))
            długa_droga = []
            for skoki in S:
                różnica = abs(x_k - y_k)
                długa_droga.append(różnica)
        return f"Alfred śpi pod dachem. Trafi tam w co najmniej {min(długa_droga)} skokach."
    else:
        return "Śpi pod gołym niebem."

# print(alferd_ma_problem(84, 228, 430)) # Alfred nie śpi w domu
# print(alferd_ma_problem(84, 228, -430)) # Alfred nadal nie śpi w domu
# print(alferd_ma_problem(84, 228, 432)) # Alferd może spać u Horacego
# print(alferd_ma_problem(84, 228, -432)) # Alfred może spać znowu u Horacego + czy - ma znaczenie
# Teraz wystarczy sprawdzić, kiedy wykona najmniej skoków, czyli sprawdzić różnicę między x_k i y_k
