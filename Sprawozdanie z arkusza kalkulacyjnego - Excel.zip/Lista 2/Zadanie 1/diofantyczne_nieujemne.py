# Zaimplementuj funkcję diofantyczne_nieujemne(a, b, c), znajdującą zbiór rozwiązań równania diofantycznego liniowego postaci ax+by=c
# (gdzie x≥0 oraz y≥0).
    # Funkcja powinna zwracać zbiór par (x, y) spełniających podane warunki
    # Jeśli nie ma rozwiązań nieujemnych lub wcale nie ma rozwiązania równania, funkcja powinna zwrócić zbiór pusty.

from Euklides import xgcd
from diofantyczne_rozwiązanie import diofantyczne_rozwiązanie
from diofantyczne_rozwiązanie import diofantyczne_ma_rozwiązanie

def diofantyczne_nieujemne(a, b, c):
    S = set()
    if diofantyczne_ma_rozwiązanie(a, b, c) is True:
        x, y = diofantyczne_rozwiązanie(a, b, c)
        gcd, _, _ = xgcd(a, b) # _ pomijamy zmienną
        m = x + b//gcd
        n = y - a//gcd
        for k in range(min(m, n), max(m, n)+1): # range przyjmuje tylko wartości całkowite, więc nie musi być int
            x_k = x + (b//gcd) * k
            y_k = y - (a//gcd) * k
            if x_k >= 0 and y_k >= 0:
                S.add((x_k, y_k))
    return S

#print(diofantyczne_nieujemne(7, 28, -4))