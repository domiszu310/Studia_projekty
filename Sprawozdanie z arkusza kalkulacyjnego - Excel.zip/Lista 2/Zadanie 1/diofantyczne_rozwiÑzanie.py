# Zaimplementuj funkcję diofantyczne_rozwiązanie(a, b, c), znajdującą dowolne rozwiązanie równania diofantycznego liniowego postaci ax+by=c.
    # Jeśli rozwiązanie istnieje funkcja powinna zwrócić parę liczb (x, y).
    # Jeśli rozwiązanie nie istnieje, funkcja powinna zwrócić None.

from diofantyczne_ma_rozwiązanie import diofantyczne_ma_rozwiązanie
from Euklides import xgcd

def diofantyczne_rozwiązanie(a, b, c):
    if diofantyczne_ma_rozwiązanie(a, b, c) is True: # z notatek po wykładzie punkt 3.2
        gcd, x_prim, y_prim = xgcd(a, b)
        x = (x_prim * c)//gcd
        y = (y_prim * c)//gcd
        return (x, y)
    else:
        return None

#print(diofantyczne_rozwiązanie(2, 15, -10))