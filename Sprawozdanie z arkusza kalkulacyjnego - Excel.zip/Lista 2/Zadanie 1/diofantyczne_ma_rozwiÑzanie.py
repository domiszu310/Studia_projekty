# Zaimplementuj funkcję diofantyczne_ma_rozwiązanie(a, b, c), sprawdzającą czy równanie diofantyczne liniowe postaci ax+by=c ma rozwiązanie. 
# Równanie ma rozwiązanie jeśli gcd{a,b} dzieli c, czyli c/gcd{a,b} == 1, czyli ax+by == 1

from Euklides import xgcd

def diofantyczne_ma_rozwiązanie(a, b, c):
    if a == 0 or b == 0:
        return False
    gcd, x, y = xgcd(a, b)
    if c%gcd == 0:
        return True
    else:
        return False
        
#print(diofantyczne_ma_rozwiązanie(18, 16, 500)) # None???
#print(xgcd(1, 2))