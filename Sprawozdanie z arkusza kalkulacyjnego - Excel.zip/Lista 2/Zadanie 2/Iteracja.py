# trzeba stworzyć trójkąt pascala, dodając odpowiednie elementy z poprzednich wierzy
# wtedy 27 po 12, to 27 wierszy i 12 kolumn

from Trójkąt_Pascala import trójkąt_Pascala

def Newton_iteracja(n, k):
    if n < k:
        raise ValueError("n jest mniejsze od k")
    pascal = trójkąt_Pascala(n+1) # musi być n+1, bo w trójkącie Pascala mamy range
    return pascal[n][k] # indeksy na liście n na liście trójkąt, a k w odpowiedniej liście n

#print(Newton_iteracja(2, 5))