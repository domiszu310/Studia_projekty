def trójkąt_Pascala(n): # n to liczba wierszy
    trójkąt = [[1]] # 1 jest pierwszym wierszem
    for i in range(1, n):
        poprzedni_wiersz = trójkąt[-1] # ostatni element na liście
        wiersz = [1] # 1 jest pierwszym elementem każdego wiersza
        for j in range(1, i): # w przypadku n = 2 ta linia jest pomijana
            wiersz.append(poprzedni_wiersz[j - 1] + poprzedni_wiersz[j]) # i razy dodajemy element j z poprzedniego wiersza i element j-1
        wiersz.append(1) # 1 jest ostatnim elementem każdego wiersza
        trójkąt.append(wiersz)
    return trójkąt
# każda kolejna lista w liście 'trójkąt' jest kolejnym wierszem trójkąta Pascala

#print(trójkąt_Pascala(3))