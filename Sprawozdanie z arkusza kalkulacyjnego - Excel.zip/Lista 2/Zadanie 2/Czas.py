from time import perf_counter
from itertools import repeat
from random import seed, randrange, setstate, getstate
import gc

def zmierz_raz(f, min_time=0.2):
    czas = 0
    ile_razy = 0
    ile_teraz = 1
    stan_gc = gc.isenabled()
    gc.disable()
    while czas < min_time:
        if ile_teraz == 1:
            start = perf_counter()
            f()
            stop = perf_counter()
        else:
            iterator = repeat(None, ile_teraz)
            start = perf_counter()
            for _ in iterator:
                f()
            stop = perf_counter()
        czas = stop-start
        ile_teraz *= 2
    if stan_gc:
        gc.enable()
    return czas/ile_teraz


def zmierz_min(f, serie_min=5, min_time=0.2):
    pomiary = []
    generator = getstate()
    seed()
    my_seed = randrange(1000)
    for _ in repeat(None, serie_min):
        seed(my_seed)
        pomiary.append(zmierz_raz(f, min_time=min_time))
    setstate(generator)
    return min(pomiary)

def zmierz(f, serie_median=10, serie_min=5, min_time=0.2): # to trawa bardzo długo, ale wydaje się być najbardziej precyzyjne
    pomiary = []
    for _ in repeat(None, serie_median):
        pomiary.append(zmierz_min(f, serie_min=serie_min, min_time=min_time))
    pomiary.sort()
    if serie_median%2==0:
        return (pomiary[serie_median//2-1]+pomiary[serie_median//2])/2
    else:
        return pomiary[serie_median//2]