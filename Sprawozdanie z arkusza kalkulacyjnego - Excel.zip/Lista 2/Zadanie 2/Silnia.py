# n po k = n! / (n-k)!k!
# ! - factorial z math

from math import factorial

def Newton_silnia(n, k):
    silnia = factorial(n)//(factorial(n-k)*factorial(k))
    return silnia

# print(Newton_silnia(5, 3))