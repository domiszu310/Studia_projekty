# n po k, czyli n na górze, k na dole
# n po n i n po 0 to 1
# n po k to n-1 po k-1 + n-1 po k
 
def Newton_rekurencja(n, k):
    if k == n or k == 0:
        return 1
    if n < k:
        raise ValueError("n jest mniejsze od k")
    return Newton_rekurencja(n-1, k-1) + Newton_rekurencja(n-1, k)

#print(Newton_rekurencja(5, 2)) # 10
#print(Newton_rekurencja(5, 3)) # 10