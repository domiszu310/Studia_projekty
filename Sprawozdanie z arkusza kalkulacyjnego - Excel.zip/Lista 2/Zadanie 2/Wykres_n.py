# n jest stałe

import numpy as np
import matplotlib.pyplot as plt
from Czas import zmierz_min
from Rekurencja import Newton_rekurencja
from Iteracja import Newton_iteracja
from Silnia import Newton_silnia

n = 10

K = [k for k in range(0, 11)]

czas_rek = [zmierz_min(lambda: Newton_rekurencja(n, k)) for k in K]
czas_iter = [zmierz_min(lambda: Newton_iteracja(n, k)) for k in K]
czas_silnia = [zmierz_min(lambda: Newton_silnia(n, k)) for k in K]

plt.plot(K, czas_rek, color = 'r', label = 'Newton_rekurencja')
plt.plot(K, czas_iter, color = 'g', label = 'Newton_iteracja')
plt.plot(K, czas_silnia, color = 'b', label = 'Newton_silnia')
plt.xlabel('wartość k')
plt.ylabel('czas')
plt.xticks(np.arange(0, 11, 1))
plt.xlim((0, 10))
plt.ylim((0, 0.0005))
plt.title('Wykres dla n = 10')
plt.legend(loc = 'best')
plt.grid()
plt.show()