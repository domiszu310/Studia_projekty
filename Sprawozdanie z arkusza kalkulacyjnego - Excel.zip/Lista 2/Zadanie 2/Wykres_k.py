# k jest stałe

import numpy as np
import matplotlib.pyplot as plt
from Czas import zmierz_min
from Rekurencja import Newton_rekurencja
from Iteracja import Newton_iteracja
from Silnia import Newton_silnia

k = 5

N = [n for n in range(5, 16)] # opłaca się wziąć n conajmniej 4, jak będzie 10 to może się zrobić ciekawie

czas_rek = [zmierz_min(lambda: Newton_rekurencja(n, k)) for n in N]
czas_iter = [zmierz_min(lambda: Newton_iteracja(n, k)) for n in N]
czas_silnia = [zmierz_min(lambda: Newton_silnia(n, k)) for n in N]

plt.plot(N, czas_rek, color = 'r', label = 'Newton_rekurencja')
plt.plot(N, czas_iter, color = 'g', label = 'Newton_iteracja')
plt.plot(N, czas_silnia, color = 'b', label = 'Newton_silnia')
plt.xlabel('wartość n')
plt.ylabel('czas')
plt.xticks(np.arange(5, 16, 1))
plt.xlim((5, 15))
plt.ylim((0, 0.013))
plt.title('Wykres dla k = 5')
plt.legend(loc = 'best')
plt.grid()
plt.show()