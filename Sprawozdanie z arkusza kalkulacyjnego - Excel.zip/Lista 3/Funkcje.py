def pierwsze_sito(N):
    if N < 2:
        return []
    kandydaci = list(range(N))
    kandydaci[0] = None
    kandydaci[1] = None
    for x in kandydaci:
        if x is None:
            continue
        if x*x >= N:
            break
        for y in range(x*x, N, x):
            kandydaci[y] = None
    return [x for x in kandydaci if x is not None]

def czynniki_pierwsze(n):
    wyniki = {}
    for p in pierwsze_sito(n+1):
        ile_razy = 0
        while n%p == 0:
            ile_razy += 1
            n //= p
        if ile_razy:
            wyniki[p] = ile_razy
    return wyniki

def wymnażaj(pary): # wypisuje wszystkie dzielniki liczby przedstawionej jako iloczyn liczb pierwszych do odpowiedniej potęgi
    if not pary:
        return [1]
    (n, k) = pary[0]
    bez_pierwszego = wymnażaj(pary[1:])
    wynik = []
    mnoznik = n
    for _ in range(k):
        wynik += [x*mnoznik for x in bez_pierwszego]
        mnoznik *= n
    return bez_pierwszego + wynik

#para = [(2, 3), (5, 7)]
#print(wymnażaj(para))

def lista_dzielników(N, właściwe = True): # zwraca TYLKO dzielnik właściwe liczby
    czynniki = list(czynniki_pierwsze(N).items())
    dzielniki = sorted(wymnażaj(czynniki))
    if właściwe:
        return dzielniki[:-1]
    else:
        return dzielniki
    
#print(lista_dzielników(1184))
#print(sum(lista_dzielników(1184)))