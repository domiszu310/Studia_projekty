krotka = (284, 1)
s = tuple(sorted(krotka)) # bez dodania tuple funkcja sorted zwraca listę
print(s)

lista = list(range(1, 11))
print(lista)

print((6-1)//2)


