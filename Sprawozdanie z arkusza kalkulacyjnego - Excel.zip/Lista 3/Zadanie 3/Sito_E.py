# sito Eratostenesa z wykładu ze zmienioną nazwą

def pierwsze_sito(N):
    if N < 2:
        return []
    kandydaci = list(range(N))
    kandydaci[0] = None
    kandydaci[1] = None
    for x in kandydaci:
        if x is None:
            continue
        if x*x >= N:
            break
        for y in range(2*x, N, x):
            kandydaci[y] = None
    return [x for x in kandydaci if x is not None]

def sito_Eratostenesa(N):
    if N < 2:
        return []
    kandydaci = list(range(N))
    kandydaci[0] = None
    kandydaci[1] = None
    for x in kandydaci:
        if x is None:
            continue
        if x*x >= N:
            break
        for y in range(x*x, N, x):
            kandydaci[y] = None
    return [x for x in kandydaci if x is not None]