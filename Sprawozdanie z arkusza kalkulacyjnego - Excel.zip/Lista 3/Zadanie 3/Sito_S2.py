# Do podstawowego algorytmu spróbuj dodać optymalizację: jak może się zmieniać wartość j przy ustalonym i,
# aby liczba postaci i+j+2ij ≤ k, czyli aby znajdowała się na liście?
from math import floor

def sito_Sundarama2(N):
    if N <= 2:
        return []
    k = floor((N - 2) / 2)
    kandydaci = [True] * (k + 1) # True to liczba potencjalnie pierwsza *(k+1) to długość listy
    for i in range(1, k+1): # pętla bierze wartość i, sprawdza dla niej wszystkie możliwe j wartości aż do podanego limitu
        for j in range(i, ((k-i)//(2*i + 1)) + 1):
            skreśl = i+j+2*i*j
            if skreśl <= k:
                kandydaci[skreśl] = False # liczby z indeksem skreśl są wykreślane
    return [2] + [2*a + 1 for a in range(1, k+1) if kandydaci[a] is True]

from Sito_E import sito_Eratostenesa

#print(sito_Sundarama2(10))
#print(sito_Eratostenesa(3))
#print(sito_Sundarama2(4) == sito_Eratostenesa(4))