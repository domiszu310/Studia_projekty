def sito_S(n):
    if n < 2:
        return []
    k = (n - 2)//2 # otrzymujemy z tego największą możliwą liczbę pierwszą dla zakresu (1, k)
    lista = list(range(1, k+1))
    for i in lista:
        for j in lista:
            if i + j + 2*i*j <= k:
                lista[i + j + 2*i*j - 1] = False
    liczby_pierwsze = [2*i + 1 for i in lista if i is not False]
    return liczby_pierwsze

#print(sito_S(20))

l = [1, 2, 3, 5, 6]
print(l[3])

def sito_SSS(n):
    if n < 2:
        return []
    k = (n - 2)//2 # skoro mają należeć (2, 2k+2)
    kandydaci = [True] * (k + 1) # True to liczba potencjalnie pierwsza *(k+1) to długość listy
    for i in range(1, k+1):
        j = i # i, j w tym samym zakresie
        skreśl = i+j+2*i*j
        while skreśl <= k: # dopóki wartość skreśl jest mniejsza równa k
            kandydaci[skreśl - 1] = False # liczby z indeksem skreśl+1 są wykreślane
            j += 1 # następna wartość j
    liczby_pierwsze = []
    for a in range(1, k+1):
        if kandydaci[a] is not False:
            liczby_pierwsze.append(2*a + 1)
    return liczby_pierwsze

def sito_SS(n):
    if n < 2:
        return []
    k = (n - 1)//2
    lista = [True] * (k + 1) # True to liczba potencjalnie pierwsza *(k+1) to długość listy
    for i in range(1, k+1):
        for j in range(i, (k-i)//(2*i + 1)+1): # bierzemy to z nierówności
            numer = i + j + 2*i*j # indeks na liście lista
            if numer <= k:
                lista[numer] = None
    liczby_pierwsze = [2*l + 1 for l in range(1, k+1) if lista[l] is not None]
    return liczby_pierwsze

#print(sito_SS(20))