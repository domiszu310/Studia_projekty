import numpy as np
import matplotlib.pyplot as plt
from Czas import zmierz_min
from Sito_E import sito_Eratostenesa
from Sito_S import sito_Sundarama
from Sito_S2 import sito_Sundarama2

L = [10*l for l in range(0, 11)] # (0, 3), (0, 10), (0, 20), (0, 100, 10)

czas_e = [zmierz_min(lambda: sito_Eratostenesa(N)) for N in L]
czas_s = [zmierz_min(lambda: sito_Sundarama(N)) for N in L]
czas_s2 = [zmierz_min(lambda: sito_Sundarama2(N)) for N in L]

plt.plot(L, czas_e, color = 'r', label = 'sito_Eratostenesa')
plt.plot(L, czas_s, color = 'g', label = 'sito_Sundarama')
plt.plot(L, czas_s2, color = 'b', label = 'sito_Sundarama2')
plt.xlabel('wartość N')
plt.ylabel('czas')
plt.xticks(np.arange(0, 101, 10))
plt.xlim((0, 100))
plt.ylim((0, 0.00013))
plt.legend(loc = 'best')
plt.grid()
plt.show()