from math import floor

def sito_Sundarama2(N):
    if N < 2:
        return []
    k = floor((N - 2) / 2)
    kandydaci = [True] * (k + 1)
    i = 1
    while i <= k:
        j = i
        while j <= (k-i)//(2*i + 1):
            skreśl = i+j+2*i*j
            kandydaci[skreśl] = False # liczby z indeksem skreśl są wykreślane
            j += 1
        i += 1
    liczby_pierwsze = [2]
    for a in range(1, k+1):
        if kandydaci[a] is not False:
            liczby_pierwsze.append(2*a + 1)
    return liczby_pierwsze
    

#print(sito_Sundarama2(10))

def sieve_of_Sundaram(n): # funkcja z Wikipedii, żeby zobaczyć, czy zwraca 2
    """The sieve of Sundaram is a simple deterministic algorithm for finding all the prime numbers up to a specified integer."""
    k = (n - 2) // 2
    integers_list = [True] * (k + 1)
    for i in range(1, k + 1):
        j = i
        while i + j + 2 * i * j <= k:
            integers_list[i + j + 2 * i * j] = False
            j += 1
    if n > 2:
        print(2, end=' ')
    for i in range(1, k + 1):
        if integers_list[i]:
            print(2 * i + 1, end=' ')

print(sieve_of_Sundaram(10))