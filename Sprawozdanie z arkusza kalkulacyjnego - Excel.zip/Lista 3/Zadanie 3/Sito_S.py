# Sito Sundarama generuje liczby pierwsze. główny pomysł implementacji przebiega następująco:
    # zaczynamy od listy liczb od 1 do k,
    # wykreślamy liczby postaci i+j+2ij, dla 0 < i, j ≤ k,
    # niewykreślone liczby mnożymy razy dwa,
        # do wyników dodajemy jeden.
# Efektem są liczby pierwsze większe od 2 i mniejsze od 2k+2.

# 1 < i <= j <= k, gdzie i, j należą do N

# Następujący wariant wygeneruje wszystkie liczby pierwsze mniejsze od N:
    # zaczynamy od listy liczb od 0 do k = podłoga(N−2 // 2),
    # wykreślamy liczby postaci i+j+2ij, dla 0<i, j≤k,
    # niewykreślone liczby mnożymy razy dwa,
        # do wyników dodajemy jeden,
    # pierwszą liczbę zastępujemy dwójką. ??? w sensie pierwsza liczba to 2? Czy jak np. było 3 jako pierwsze, to 3 wypada i jest 2?

# Napisz funkcję sito_Sundarama(N), która wygeneruje liczby pierwsze mniejsze od N.
    # Wyniki porównaj z wynikami uzyskanymi za pomocą sita Eratostenesa z wykładu.

from math import floor

def sito_Sundarama(N):
    if N <= 2:
        return []
    k = floor((N - 2) // 2)
    kandydaci = [True] * (k + 1) # True to liczba potencjalnie pierwsza, *(k+1) to długość listy, k+1, żeby było od 0 do k, bo lista ma indeksy od 0
    for i in range(1, k+1):
        for j in range(1, k+1):
            skreśl = i+j+2*i*j
            if skreśl > k: # jeśli wartość skreśl jest większa od k, to pętla jest przerywana, co znaczenie przyspiesza działanie algorytmu
                break
            kandydaci[skreśl] = False # liczby z indeksem skreśl są wykreślane
    return [2] + [2*a + 1 for a in range(1, k+1) if kandydaci[a] is True]

from Sito_E import sito_Eratostenesa

#print(sito_Sundarama(10))
#print(sito_Eratostenesa(12))
#print(sito_Sundarama(4) == sito_Eratostenesa(4))




