# Napisz program liczący ile jest par liczb zaprzyjaźnionych mniejszych od N. Przetestuj go dla N=10000.

# Liczby zaprzyjaźnione czyli tak jakby liczby doskonałe ale o okresie 2

from Funkcje import lista_dzielników
from Zadanie1 import czy_doskonała

def czy_zaprzyjaźniona(n): # podajemy liczbę n, a funkcja zwraca liczbę wraz z jej "przyjaciółką", chyba że taka nie istnieje wtedy False
    dzielniki_n = lista_dzielników(n)
    suma_n = sum(dzielniki_n)
    for i in range(1, suma_n+1): # można spróbować bez range, bo nie wiemy jak duża może być ta liczba zaprzyjaźniona
        dzielniki_i = lista_dzielników(i)
        suma_i = sum(dzielniki_i)
        if suma_i == n and suma_n == i:
            return (i, n)
    return False

#print(czy_zaprzyjaźniona(1184))
        
def BFF(N): # best friends forever
    przyjaciele = []
    for i in range(1, N): # ma być mniejszych od N, więc bez N
        if czy_doskonała(i) is not True:
            para_1 = czy_zaprzyjaźniona(i)
            if para_1 is not False:
                para_2 = tuple(sorted(para_1)) # sorted zwraca listę, więc trzeba dodać tuple
                if para_2 not in przyjaciele:
                    przyjaciele.append(para_2)
    return len(przyjaciele)

#N = 10000
#print(BFF(N))

