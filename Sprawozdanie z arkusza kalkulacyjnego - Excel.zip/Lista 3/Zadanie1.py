# Napisz program szukający liczb doskonałych mniejszych od N. Przetestuj go dla N=100.

from Funkcje import lista_dzielników

def czy_doskonała(N): # sprawdza czy liczba jest doskonała i zwraca True albo False
    return N == sum(lista_dzielników(N))

# print(czy_doskonała(6))

def doskonałe_N(N): # wraca wszystkie liczby doskonałe mniejsze od N
    ideał = []
    for i in range (1, N): # chcemy mniejsze od N, więc nie bierzumy jest do range
        if czy_doskonała(i) is True:
            ideał.append(i)
    return ideał

#N = 100
#print(doskonałe_N(N))

#print(czy_doskonała(1184))